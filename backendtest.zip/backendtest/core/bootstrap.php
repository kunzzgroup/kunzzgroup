<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('ROOT_PATH', dirname(__DIR__));
define('CORE_PATH', ROOT_PATH . '/core');
define('API_PATH', ROOT_PATH . '/api');
define('MODULE_PATH', ROOT_PATH . '/modules');
define('PAGE_PATH', ROOT_PATH . '/pages');

require_once CORE_PATH . '/init.php';
require_once CORE_PATH . '/db.php';
require_once CORE_PATH . '/helpers.php';
